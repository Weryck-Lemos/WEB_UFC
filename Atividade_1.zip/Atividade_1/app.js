const nome = document.getElementById('nome');
const n1 = document.getElementById('n1');
const n2 = document.getElementById('n2');
const addBtn = document.getElementById('add');
const clearBtn = document.getElementById('clear');
const tbody = document.getElementById('tbody');


function toNum(v){
    const x = parseFloat(String(v).replace(',', '.'));
    return Number.isFinite(x) ? x : NaN;
}


function media2(a, b){
    return (a + b) / 2;
}


function situacao(media){
    return media >= 7 ? 'Aprovado' : 'Reprovado';
}


function classe(media){
    return media >= 7 ? 'aprovado' : 'reprovado';
}


function format(n){
    return Number(n).toFixed(2).replace('.', ',');
}


function addAluno(){
    const nomeVal = (nome.value || '').trim();
    const n1Val = toNum(n1.value);
    const n2Val = toNum(n2.value);



    if(!nomeVal){ alert('Informe o nome do aluno.'); nome.focus(); return; }
    if(!Number.isFinite(n1Val) || n1Val < 0 || n1Val > 10){ alert('Nota 1 inválida (0 a 10).'); n1.focus(); return; }
    if(!Number.isFinite(n2Val) || n2Val < 0 || n2Val > 10){ alert('Nota 2 inválida (0 a 10).'); n2.focus(); return; }


    const m = media2(n1Val, n2Val);
    const tr = document.createElement('tr');
    tr.className = classe(m);
    tr.innerHTML = `
        <td>${escapeHtml(nomeVal)}</td>
        <td>${format(n1Val)}</td>
        <td>${format(n2Val)}</td>
        <td><strong>${format(m)}</strong></td>
        <td>${situacao(m)}</td>
    `;


    tbody.appendChild(tr);


    nome.value = '';
    n1.value = '';
    n2.value = '';
    nome.focus();
}


function escapeHtml(s){
    return s.replace(/[&<>"']/g, c => ({
        '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'
    })[c]);
}


addBtn.addEventListener('click', addAluno);

nome.addEventListener('keydown', e => { if(e.key === 'Enter') n1.focus(); });
n1.addEventListener('keydown', e => { if(e.key === 'Enter') n2.focus(); });
n2.addEventListener('keydown', e => { if(e.key === 'Enter') addAluno(); });

clearBtn.addEventListener('click', () => { tbody.innerHTML = ''; });

tbody.addEventListener('click', (e) => {
    const tr = e.target.closest('tr');
    if(tr) tr.remove();
});